#!/usr/bin/env python3
"""
长期记忆模块 - 支持 Agent 跨生命周期状态管理

存储位置: 项目根目录下的 evolution_memory.json
"""

import json
import os
from typing import Optional
from datetime import datetime


MEMORY_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "evolution_memory.json")


def _get_default_memory() -> dict:
    """获取默认的记忆结构"""
    return {
        "generation": 1,
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat(),
        "learned_lessons": [],
        "current_long_term_goal": "不断优化自身代码并存活",
        "survival_count": 0,
    }


def _load_memory() -> dict:
    """从文件加载记忆，如果不存在则初始化"""
    if not os.path.exists(MEMORY_FILE):
        memory = _get_default_memory()
        _save_memory(memory)
        return memory
    
    try:
        with open(MEMORY_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        memory = _get_default_memory()
        _save_memory(memory)
        return memory


def _save_memory(memory: dict) -> bool:
    """保存记忆到文件"""
    try:
        memory["updated_at"] = datetime.now().isoformat()
        with open(MEMORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(memory, f, ensure_ascii=False, indent=2)
        return True
    except IOError as e:
        return False


def read_long_term_memory() -> str:
    """
    读取 Agent 的长期记忆库。

    Returns:
        记忆库的 JSON 字符串，包含:
        - generation: 当前代数（每次重启递增）
        - learned_lessons: 学到的经验教训列表
        - current_long_term_goal: 当前长期目标
        - survival_count: 存活次数
        - updated_at: 最后更新时间

    Example:
        >>> result = read_long_term_memory()
        >>> print(result)
        {"generation": 3, "learned_lessons": [...], ...}
    """
    memory = _load_memory()
    
    summary = {
        "generation": memory.get("generation", 1),
        "learned_lessons": memory.get("learned_lessons", []),
        "current_long_term_goal": memory.get("current_long_term_goal", ""),
        "survival_count": memory.get("survival_count", 0),
        "created_at": memory.get("created_at", ""),
        "updated_at": memory.get("updated_at", ""),
    }
    
    return json.dumps(summary, ensure_ascii=False, indent=2)


def update_long_term_memory(new_goal: str, new_lesson: str) -> str:
    """
    更新 Agent 的长期记忆库。

    在每次调用 trigger_self_restart 重启自己之前，必须调用此函数来保存状态。
    会自动增加代数 (generation + 1)，追加新的经验教训，并更新长期目标。

    Args:
        new_goal: 希望下一个生命周期的自己去完成的任务
        new_lesson: 在这个生命周期里学到的东西

    Returns:
        更新后的记忆库 JSON 字符串，操作失败返回错误信息

    Example:
        >>> result = update_long_term_memory(
        ...     new_goal="优化日志输出格式",
        ...     new_lesson="修改 AST 时容易漏掉 import，下次要注意"
        ... )
    """
    memory = _load_memory()
    
    memory["generation"] = memory.get("generation", 1) + 1
    memory["survival_count"] = memory.get("survival_count", 0) + 1
    memory["current_long_term_goal"] = new_goal
    memory["updated_at"] = datetime.now().isoformat()
    
    lesson_entry = {
        "generation": memory["generation"],
        "lesson": new_lesson,
        "timestamp": datetime.now().isoformat(),
    }
    
    lessons = memory.get("learned_lessons", [])
    lessons.append(lesson_entry)
    memory["learned_lessons"] = lessons[-100:]  # 保留最近 100 条
    
    if _save_memory(memory):
        return json.dumps({
            "status": "success",
            "generation": memory["generation"],
            "message": f"记忆已更新，当前代数: {memory['generation']}"
        }, ensure_ascii=False)
    else:
        return json.dumps({
            "status": "error",
            "message": "保存记忆失败，请检查文件权限"
        }, ensure_ascii=False)


def get_memory_context() -> str:
    """
    获取格式化后的记忆上下文，用于注入到 Prompt 中。
    
    Returns:
        人类可读的记忆摘要字符串
    """
    memory = _load_memory()
    
    lines = [
        f"【代数】: {memory.get('generation', 1)}",
        f"【长期目标】: {memory.get('current_long_term_goal', '无')}",
        f"【存活次数】: {memory.get('survival_count', 0)}",
    ]
    
    lessons = memory.get("learned_lessons", [])
    if lessons:
        lines.append("【经验教训】:")
        for i, lesson in enumerate(lessons[-5:], 1):  # 显示最近 5 条
            gen = lesson.get("generation", "?")
            text = lesson.get("lesson", "")
            lines.append(f"  {i}. [G{gen}] {text}")
    
    return "\n".join(lines)
